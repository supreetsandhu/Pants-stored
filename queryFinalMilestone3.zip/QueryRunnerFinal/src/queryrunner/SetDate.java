package queryrunner;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SetDate {
    DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
    Date now = new Date();
}
