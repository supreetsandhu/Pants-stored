/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.util.ArrayList;
import java.util.Scanner;
import javax.management.Query;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class 
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {

    
    public QueryRunner()
    {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error="";
    
        
        // TODO - You will need to change the queries below to match your queries.
        
        // You will need to put your Project Application in the below variable
        
        this.m_projectTeamApplication="Clothing Shop";    // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        //this.m_projectTeamApplication="milestone_2";

        // Each row that is added to m_queryArray is a separate query. It does not work on Stored procedure calls.
        // The 'new' Java keyword is a way of initializing the data that will be added to QueryArray. Please do not change
        // Format for each row of m_queryArray is: (QueryText, ParamaterLabelArray[], LikeParameterArray[], IsItActionQuery, IsItParameterQuery)
        
        //    QueryText is a String that represents your query. It can be anything but Stored Procedure
        //    Parameter Label Array  (e.g. Put in null if there is no Parameters in your query, otherwise put in the Parameter Names)
        //    LikeParameter Array  is an array I regret having to add, but it is necessary to tell QueryRunner which parameter has a LIKE Clause. If you have no parameters, put in null. Otherwise put in false for parameters that don't use 'like' and true for ones that do.
        //    IsItActionQuery (e.g. Mark it true if it is, otherwise false)
        //    IsItParameterQuery (e.g.Mark it true if it is, otherwise false)
        
        m_queryArray.add(new QueryData("Select * from customer", null, null, false, false));   // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        m_queryArray.add(new QueryData("Select * from staff where staff_id=?", new String [] {"Staff_id"}, new boolean [] {false},  false, true));        // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        m_queryArray.add(new QueryData("Select * from order_info where customer_id like ?", new String [] {"CUSTOMER_ID:"}, new boolean [] {true}, false, true));        // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        m_queryArray.add(new QueryData("insert into payment (bill_number, payment_type) values (?,?)",new String [] {"Bill_number", "Payment_type:"}, new boolean [] {false, false}, true, true));// THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        m_queryArray.add(new QueryData("Select * from product where product_name like ? ORDER BY product_price", new String [] {"Product Name:"}, new boolean [] {true}, false, true));
        m_queryArray.add(new QueryData("Select * from shipping where shipping_status like ? ORDER BY shipping_date", new String [] {"Shipping status:"}, new boolean [] {true}, false, true));
        m_queryArray.add(new QueryData("Select customer.first_name, order_info.order_detail from customer join order_info using(customer_id) where order_info.order_detail like '%GIFT%' GROUP BY customer.customer_id", null, null, false, false));
        m_queryArray.add(new QueryData("SELECT \n" +
                "    AVG(product_price) as AVG_PRICE,\n" +
                "\tMAX(product_price) as MAX_PRICE,\n" +
                "\tMIN(product_price) as MIN_PRICE,\n" +
                "    SUM(product_price) as TOTAL_PRICE,\n" +
                "\tsupplier.name as SUPPLIER\n" +
                "FROM\n" +
                "    product\n" +
                "    JOIN supplier USING (supplier_id)\n" +
                "WHERE Product_Name = \"Slacks\"\n" +
                "GROUP BY supplier_id\n" +
                "ORDER BY supplier.name", null, null, false, false));
        m_queryArray.add(new QueryData("SELECT \n" +
                "    p.Product_name,\n" +
                "    p.Product_Price,\n" +
                "    p.product_Quantity,\n" +
                "    c.color_type,\n" +
                "    s.waist_size\n" +
                "FROM\n" +
                "    product p\n" +
                "        INNER JOIN\n" +
                "    fabric_color c ON p.fabric_color_code = c.Fabric_Color_Code\n" +
                "        INNER JOIN\n" +
                "    pants_size s ON p.Pants_Size_Code = s.Pants_Size_Code\n" +
                "WHERE p.Product_Name like ? " +
                "ORDER BY p.Product_name , p.Product_Price", new String [] {"product_name"}, new boolean [] {false},  false, true));

    }
       

    public int GetTotalQueries()
    {
        return m_queryArray.size();
    }
    
    public int GetParameterAmtForQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }
              
    public String  GetParamText(int queryChoice, int parmnum )
    {
       QueryData e=m_queryArray.get(queryChoice);        
       return e.GetParamText(parmnum); 
    }   

    public String GetQueryText(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetQueryString();        
    }
    
    /**
     * Function will return how many rows were updated as a result
     * of the update query
     * @return Returns how many rows were updated
     */
    
    public int GetUpdateAmount()
    {
        return m_updateAmount;
    }
    
    /**
     * Function will return ALL of the Column Headers from the query
     * @return Returns array of column headers
     */
    public String [] GetQueryHeaders()
    {
        return m_jdbcData.GetHeaders();
    }
    
    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     * @return multi-dimensional array of String data based on the resultset 
     * from the query
     */
    public String[][] GetQueryData()
    {
        return m_jdbcData.GetData();
    }

    public String GetProjectTeamApplication()
    {
        return m_projectTeamApplication;        
    }
    public boolean  isActionQuery (int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }
    
    public boolean isParameterQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryParm();
    }
    
     
    public boolean ExecuteQuery(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
        return bOK;
    }
    
     public boolean ExecuteUpdate(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }   
    
      
    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase)
    {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (bConnect == false)
            m_error = m_jdbcData.GetError();        
        return bConnect;
    }
    
    public boolean Disconnect()
    {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return true;
    }
    
    public String GetError()
    {
        return m_error;
    }
 
    private QueryJDBC m_jdbcData;
    private String m_error;    
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;  
    private int m_updateAmount;

    private static int printAttributes(String[] attributes)
    {
        for (int i = 0; i < attributes.length; i++)
        {
            //reformat into printf statements.
//            System.out.print(attributes[i] +"  |  ");
            System.out.printf("      %18s  ", attributes[i]);
//            System.out.print(" | ");

        }
        System.out.println(" ");

        return 1;
    }

    private static int printFunction (String[][] result)
    {
        //reformat into printf statements.
        //give each attribute / result 15 spaces.
        for(int rowIndex = 0; rowIndex<result.length; rowIndex++)
        {
            String[] row = result[rowIndex];
            System.out.printf( "%1d:", rowIndex);
            for(int colIndex = 0; colIndex< row.length; colIndex++)
                System.out.printf("   %20s   ", row[colIndex]);
            System.out.println();
        }
        return 1;
    }

    private static int holdingFunction(int i, QueryRunner queryrunner, Scanner keyboard)
    {

        if (queryrunner.GetParameterAmtForQuery(i) > 0)
        {
            int amt = queryrunner.GetParameterAmtForQuery(i);
            String[] params = new String[amt];
            System.out.println();
            System.out.println("The query " + (i+1)  + " has " + amt + " parameters.");


            for (int j = 0; j < amt; j++)
            {
                System.out.println("Param " + (j+1) + ":");
                System.out.print(queryrunner.GetParamText(i, j));
                System.out.println();
                System.out.println("Please input a value for the query: ");

                params[j] = keyboard.next();
            }

            if (queryrunner.isActionQuery(i))
            {
                queryrunner.ExecuteUpdate(i, params);
                System.out.println("Rows updated: " + queryrunner.GetUpdateAmount());
            }
            else
            {
                queryrunner.ExecuteQuery(i, params);
                //var
                String[][] result = queryrunner.GetQueryData();
                //var
                String[]attributes = queryrunner.GetQueryHeaders();
                if(result == null)
                {
                    System.out.println("There were no results.");
                }
                else
                {
                    printAttributes(attributes);
                    printFunction(result);
                }
            }

        }
        else
        {

            System.out.println("The Query response of query " + (i+1) + " is :");


            String[] params = new String[0]; // needed for an empty params array.
            queryrunner.ExecuteQuery(i, params);
            //var
            String[][]result = queryrunner.GetQueryData();
            //var
            String[]attributes = queryrunner.GetQueryHeaders();

            if(result == null)
            {
                System.out.println("There were no results.");
            }
            else
            {
                printAttributes(attributes);

                printFunction(result);
            }
        }

        return 1;
    }


    /**
     * @param args the command line arguments
     */



    public static void main(String[] args) {
        // TODO code application logic here

        Scanner c = new Scanner(System.in);

        // allows the user to select GUI or console version when they start the program
        System.out.println("GUI or console version?");
        System.out.println("1 GUI");
        System.out.println("2 Console");
        System.out.println("Enter choice number: ");
        String choice = c.nextLine();

        final QueryRunner queryrunner = new QueryRunner();

        if (choice.equals("1")) // GUI version
        {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {

                    new QueryFrame(queryrunner).setVisible(true);
                }
            });
        }
        else if (choice.equals("2")) // console version
        {
            Scanner keyboard = new Scanner(System.in);

            String hostname;
            String username;
            String password;
            String databasename = "milestone2"; //this is to print proper welcome message.
            boolean connected = false;

            while (!connected)
            {

                System.out.println("Welcome. Please input hostname: ");
                hostname = keyboard.nextLine();
                System.out.println("host is : " + hostname);

                System.out.println("Please input username: ");
                username = keyboard.nextLine();
                System.out.println("username is : " + username);

                System.out.println("Please input password: ");
                password = keyboard.nextLine();
                System.out.println("password is : " + password);

                System.out.println("Please input database name: ");
                databasename = keyboard.nextLine();
                System.out.println("database name is : " + databasename);

                connected = queryrunner.Connect(hostname, username, password, databasename);

                if(!connected)
                    System.out.println("Error connecting. Please try again");
            }
            System.out.println("Welcome to " + databasename);

            int n = queryrunner.GetTotalQueries();
            int i = 0;

            do
            {
                System.out.println("Please enter your query number, 1-7.");
                i = keyboard.nextInt();
                i--;
            } while (i < 0);

            do
            {
                holdingFunction(i,queryrunner, keyboard);
                System.out.println("Please enter your next query number, 1-7, or -1 to exit");
                i = keyboard.nextInt();
                i--; //so users can input the proper numerical query number, but the array offset is -1.

            } while (i < n && i >= 0);

            keyboard.close();

            try
            {
                queryrunner.Disconnect();
            } catch (Exception e)
            {
                System.out.println("Goodbye!");
            };
        }
//        final QueryRunner queryrunner = new QueryRunner();
//
//        if (args.length == 0)
//        {
//            java.awt.EventQueue.invokeLater(new Runnable() {
//                public void run() {
//
//                    new QueryFrame(queryrunner).setVisible(true);
//                }
//            });
//        }
//        else
//        {
//            if (args[0].equals ("-console"))
//            {
//            	System.out.println("Nothing has been implemented yet. Please implement the necessary code");
//               // TODO
//                // You should code the following functionality:
//
//                //    You need to determine if it is a parameter query. If it is, then
//                //    you will need to ask the user to put in the values for the Parameters in your query
//                //    you will then call ExecuteQuery or ExecuteUpdate (depending on whether it is an action query or regular query)
//                //    if it is a regular query, you should then get the data by calling GetQueryData. You should then display this
//                //    output.
//                //    If it is an action query, you will tell how many row's were affected by it.
//                //
//                //    This is Psuedo Code for the task:
//                //    Connect()
//                //    n = GetTotalQueries()
//                //    for (i=0;i < n; i++)
//                //    {
//                //       Is it a query that Has Parameters
//                //       Then
//                //           amt = find out how many parameters it has
//                //           Create a paramter array of strings for that amount
//                //           for (j=0; j< amt; j++)
//                //              Get The Paramater Label for Query and print it to console. Ask the user to enter a value
//                //              Take the value you got and put it into your parameter array
//                //           If it is an Action Query then
//                //              call ExecuteUpdate to run the Query
//                //              call GetUpdateAmount to find out how many rows were affected, and print that value
//                //           else
//                //               call ExecuteQuery
//                //               call GetQueryData to get the results back
//                //               print out all the results
//                //           end if
//                //      }
//                //    Disconnect()
//
//
//                // NOTE - IF THERE ARE ANY ERRORS, please print the Error output
//                // NOTE - The QueryRunner functions call the various JDBC Functions that are in QueryJDBC. If you would rather code JDBC
//                // functions directly, you can choose to do that. It will be harder, but that is your option.
//                // NOTE - You can look at the QueryRunner API calls that are in QueryFrame.java for assistance. You should not have to
//                //    alter any code in QueryJDBC, QueryData, or QueryFrame to make this work.
////                System.out.println("Please write the non-gui functionality");
//
//            }
//        }
 
    }    
}
