package queryrunner;

public class SplashClass {

    public static void main (String[] args)
    {
        QueryRunner fe = new QueryRunner();
        Splash splash = new Splash();
        splash.setVisible(true);
        QueryFrame f = new QueryFrame(fe);
        f.getContentPane().setBackground(java.awt.Color.PINK);
        try{
            for (int i = 0; i <=100; i++)
            {
                Thread.sleep(16);
                splash.progressjLabel.setText(Integer.toString(i) + "%");
                splash.loadingJProgressBar.setValue(i);
                if(i == 100)
                {
                    splash.setVisible(false);
                    f.setVisible(true);

                }
            }
        }catch (Exception e)
        {

        }
    }
}
